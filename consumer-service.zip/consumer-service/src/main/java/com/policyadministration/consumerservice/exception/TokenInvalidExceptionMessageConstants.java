package com.policyadministration.consumerservice.exception;

/**Class to hold constants*/
public class TokenInvalidExceptionMessageConstants
{
	/**Message which will be input for token invalid exception*/
	public final static String INVALIDMESSAGE = "Token Expired Please Login Again!";
}