package com.policyadministration.consumerservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.policyadministration.consumerservice.model.PropertyMaster;

/**JPA Repository which interacts with database*/
@Repository
public interface PropertyMasterRepository extends JpaRepository<PropertyMaster, Integer> 
{
	/**
	 * @param propertyAge
	 * @return Integer
	 */
	@Query(value = "select p.index from PropertyMaster p where p.minAge<=?1 and ?1<=p.maxAge")
	public Integer findIndexValue(Integer propertyAge);
}