package com.policyadministration.consumerservice.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**Model class which holds the object of consumer details as well as business details*/
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ConsumerBusiness 
{
	/**
	 * Objects for the model class which holds consumer details
	 */
	private ConsumerDetails consumerDetails;
	/**
	 * Objects for the model class which holds business details
	 */
	private BusinessDetails businessDetails;
}