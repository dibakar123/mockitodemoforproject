package com.policyadministration.consumerservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.policyadministration.consumerservice.exception.BusinessNotFoundException;
import com.policyadministration.consumerservice.exception.PropertyNotFoundException;
import com.policyadministration.consumerservice.exception.TokenInvalidException;
import com.policyadministration.consumerservice.model.BusinessDetails;
import com.policyadministration.consumerservice.model.ConsumerBusiness;
import com.policyadministration.consumerservice.model.PropertyDetails;
import com.policyadministration.consumerservice.service.ConsumerService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.java.Log;


@Log
@RestController
@Api(produces = "application/json",value="Creating and editing the consumer business as well as property")
public class ConsumerController {
	/** Service class which holds the business logic*/
	@Autowired
	private ConsumerService consumerService;

	@ApiOperation(value = "Creates consumer business",response = ResponseEntity.class)
	@PostMapping("/createConsumerBusiness")
	public ResponseEntity<BusinessDetails> createConsumerBusiness(@RequestBody ConsumerBusiness consumerBusiness,
			@RequestHeader("Authorization") String authorizationToken)
			throws Exception {
		log.info("INSIDE CREATE CONSUMER BUSINESS CONTROLLER");
		BusinessDetails businessDetails = consumerService.createConsumerBusiness(consumerBusiness, authorizationToken);
		ResponseEntity<BusinessDetails> response = new ResponseEntity<BusinessDetails>(businessDetails,HttpStatus.OK);
		log.info("INSIDE END OF CONSUMER BUSINESS CONTROLLER");
		return response;
	}

	@ApiOperation(value = "Creates consumer property",response = ResponseEntity.class)
	@PostMapping("/createBusinessProperty/{businessId}")
	public ResponseEntity<PropertyDetails> createBusinessProperty(@RequestBody PropertyDetails propertyDetails,
			@PathVariable("businessId") Long businessId, @RequestHeader("Authorization") String authorizationToken)
			throws Exception{
		log.info("INSIDE CREATE CONSUMER BUSINESS PROPERTY CONTROLLER");
		PropertyDetails propertyDetail = consumerService.createBusinessProperty(propertyDetails, businessId, authorizationToken);
		ResponseEntity<PropertyDetails> response = new ResponseEntity<PropertyDetails>(propertyDetail,HttpStatus.OK);
		log.info("END OF CREATE CONSUMER BUSINESS PROPERTY CONTROLLER");
		return response;
	}

	@ApiOperation(value = "Return the consumer business based on the business id",response = BusinessDetails.class)
	@GetMapping("/viewConsumerBusiness/{businessId}")
	public BusinessDetails viewConsumerBusiness(@PathVariable("businessId") Long businessId,
			@RequestHeader("Authorization") String authorizationToken) throws Exception {
		log.info("INSIDE VIEW CONSUMER BUSINESS CONTROLLER");
		log.info("END OF CONSUMER BUSINESS CONTROLLER");
		return consumerService.viewConsumerBusiness(businessId, authorizationToken);
	}

	@ApiOperation(value = "Return the business property based on the business and property id",response = PropertyDetails.class)
	@GetMapping("/viewConsumerProperty/business/{businessId}/property/{propertyId}")
	public PropertyDetails viewConsumerProperty(@PathVariable("businessId") Long businessId,
			@PathVariable("propertyId") Long propertyId, @RequestHeader("Authorization") String authorizationToken)
			throws Exception {
		log.info("INSIDE VIEW CONSUMER PROPERTY");
		log.info("END OF VIEW CONSUMER PROPERTY");
		return consumerService.viewPropertyDetails(businessId, propertyId, authorizationToken);
	}

	@ApiOperation(value = "update the consumer business details based on the consumer id")
	@PutMapping("/updateConsumerBusiness/{consumerId}")
	public void updateConsumerBusiness(@RequestBody ConsumerBusiness consumerBusiness,
			@PathVariable("consumerId") Long consumerId, @RequestHeader("Authorization") String authorizationToken)
			throws Exception {
		log.info("INSIDE UPDATE CONSUMER BUSINESS");
		consumerService.updateConsumerBusiness(consumerId, consumerBusiness, authorizationToken);
		log.info("END OF UPDATE CONSUMER BUSINESS");
	}

	@ApiOperation(value = "update the business property based on the business and property id")
	@PutMapping("/updateBusinessProperty/business/{businessId}/property/{propertyId}")
	public void updateBusinessProperty(@RequestBody PropertyDetails propertyDetails,
			@PathVariable("businessId") Long businessId, @PathVariable("propertyId") Long propertyId,
			@RequestHeader("Authorization") String authorizationToken) 
			throws Exception {
		log.info("INSIDE UPDATE CONSUMER BUSINESS PROPERTY");
		consumerService.updateBusinessProperty(businessId, propertyId, propertyDetails, authorizationToken);
		log.info("END OF UPDATE CONSUMER BUSINESS PROPERTY");
	}
}