package com.policyadministration.consumerservice.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**Model class for the business details*/
@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class BusinessDetails 
{
	/**
	 *Id of the business 
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long businessId;
	/**
	 *Description of business 
	 */
	@NotEmpty(message = "Business description canot be empty")
	@Pattern(regexp = "[A-z]+",message = "Business description must be in words")
	private String businessDescription;
	/**
	 *Type of the business
	 */
	@NotEmpty(message = "Business type cannot be empty")
	@Pattern(regexp = "[A-z]+",message = "Business type must be in words")
	private String businessType;
	/**
	 *Annual Turn over of the business
	 */
	@NotNull(message = "Annual Turnover must not be empty")
	private Double annualTurnover;
	/**
	 *Total number of employees
	 */
	@NotNull(message = "Employess cannot be empty")
	@Min(value = 1,message = "There Must be atleast one employee")
	private Long totalNoOfEmployees;
	/**
	 *Capital Invested for the business 
	 */
	@NotNull(message = "Capital Invested must not be empty")
	private Double capitalInvested;
	/**
	 *Index value of the business
	 */
	private Integer indexValue = 0;
	/**
	 *Object which holds details of the consumer
	 */
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "consumerId")
	private ConsumerDetails consumerDetails;
}