package com.policyadministration.consumerservice.exception;

/**Custom exception class*/
public class BusinessNotFoundException extends Exception 
{
	/**
	 * @param message
	 * @return nothing
	 */
	public BusinessNotFoundException(String message) 
	{
		super(message);
	}
}