package com.policyadministration.consumerservice.model;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
/**
 * Model class which is used for property master database
 */
@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class PropertyMaster 
{
	/**
	 *Id of the entity class 
	 */
	@Id
	private Integer id;
	/**
	 *Minimum age of the property 
	 */
	private Integer minAge;
	/**
	 *Maximum age of the property 
	 */
	private Integer maxAge;
	/**
	 *Index value of the property 
	 */
	private Integer index;
}