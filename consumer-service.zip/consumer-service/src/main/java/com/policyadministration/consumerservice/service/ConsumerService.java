package com.policyadministration.consumerservice.service;

import com.policyadministration.consumerservice.exception.BusinessNotFoundException;
import com.policyadministration.consumerservice.exception.PropertyNotFoundException;
import com.policyadministration.consumerservice.exception.TokenInvalidException;
import com.policyadministration.consumerservice.model.BusinessDetails;
import com.policyadministration.consumerservice.model.ConsumerBusiness;
import com.policyadministration.consumerservice.model.PropertyDetails;

/** Interface which have the methods of service class */
public interface ConsumerService 
{
	/**
	 * @param consumerBusiness
	 * @param authorizationToken
	 * @return BusinessDetails
	 * @throws TokenInvalidException
	 */
	public BusinessDetails createConsumerBusiness(ConsumerBusiness consumerBusiness, String authorizationToken) throws Exception;

	/**
	 * @param propertyDetails
	 * @param id
	 * @param authorizationToken
	 * @return PropertyDetails
	 * @throws TokenInvalidException
	 * @throws BusinessNotFoundException
	 */
	public PropertyDetails createBusinessProperty(PropertyDetails propertyDetails, Long id,
			String authorizationToken) throws Exception;

	/**
	 * @param businessId
	 * @param authorizationToken
	 * @return BusinessDetails
	 * @throws TokenInvalidException
	 * @throws BusinessNotFoundException
	 * @throws Exception 
	 */
	public BusinessDetails viewConsumerBusiness(Long businessId, String authorizationToken) throws Exception;

	/**
	 * @param businessId
	 * @param propertyId
	 * @param authorizationToken
	 * @return PropertyDetails
	 * @throws TokenInvalidException
	 * @throws PropertyNotFoundException
	 */
	public PropertyDetails viewPropertyDetails(Long businessId, Long propertyId, String authorizationToken) throws Exception;

	/**
	 * @param consumerId
	 * @param consumerBusiness
	 * @param authorizationToken
	 * @throws TokenInvalidException
	 * @throws BusinessNotFoundException
	 */
	public void updateConsumerBusiness(Long consumerId, ConsumerBusiness consumerBusiness, String authorizationToken) throws Exception;

	/**
	 * @param businessId
	 * @param propertyId
	 * @param propertyDetails
	 * @param authorizationToken
	 * @throws TokenInvalidException
	 * @throws PropertyNotFoundException
	 */
	public void updateBusinessProperty(Long businessId, Long propertyId, PropertyDetails propertyDetails,
			String authorizationToken) throws Exception;
}