package com.policyadministration.consumerservice.exception;

/**Custom exception class*/
public class PropertyNotFoundException extends Exception  {
	/**
	 * @param message
	 * @return nothing
	 */
	public PropertyNotFoundException(String message) 
	{
		super(message);
	}

}
