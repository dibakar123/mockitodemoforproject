package com.policyadministration.consumerservice.service;

import java.util.NoSuchElementException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.policyadministration.consumerservice.exception.BusinessNotFoundException;
import com.policyadministration.consumerservice.exception.PropertyNotFoundException;
import com.policyadministration.consumerservice.exception.TokenInvalidException;
import com.policyadministration.consumerservice.exception.TokenInvalidExceptionMessageConstants;
import com.policyadministration.consumerservice.feign.AuthenticationProxy;
import com.policyadministration.consumerservice.model.BusinessDetails;
import com.policyadministration.consumerservice.model.ConsumerBusiness;
import com.policyadministration.consumerservice.model.ConsumerDetails;
import com.policyadministration.consumerservice.model.PropertyDetails;
import com.policyadministration.consumerservice.repository.BusinessMasterRepository;
import com.policyadministration.consumerservice.repository.BusinessRepository;
import com.policyadministration.consumerservice.repository.PropertyMasterRepository;
import com.policyadministration.consumerservice.repository.PropertyRepository;
import com.policyadministration.consumerservice.util.JwtUtil;

import lombok.extern.java.Log;

/**Service class which holds the business logic*/
@Log
@Service
public class ConsumerServiceImpl implements ConsumerService {
	/**Repository which holds business details*/
	@Autowired
	private BusinessRepository businessRepository;

	/**Repository which holds property details*/
	@Autowired
	private PropertyRepository propertyRepository;

	/**Repository which holds the index value for business value*/
	@Autowired
	private BusinessMasterRepository businessMasterRepository;
	
	/**Repository which holds the index value for property value*/
	@Autowired
	private PropertyMasterRepository propertyMasterRepository;

	/**Proxy(FeignClient) for authentication service*/
	@Autowired
	private AuthenticationProxy authenticationProxy;

	/**Utility class to do extract details from JWT*/
	@Autowired
	private JwtUtil jwtUtil;

	/**
	 *@param consumerBusiness
	 *@param authorizationToken
	 *@throws TokenInvalidException
	 *@return BusinessDetails
	 */
	@Override
	public BusinessDetails createConsumerBusiness(ConsumerBusiness consumerBusiness,
			String authorizationToken) throws Exception {
		log.info("INSIDE CREATE CONSUMER BUSINESS SERVICE");
		boolean valid = authenticationProxy.getValidity(authorizationToken).isValid();
		
		if (valid) {
			Integer indexValue = 0;
			BusinessDetails businessDetails = consumerBusiness.getBusinessDetails();
			ConsumerDetails consumerDetails = consumerBusiness.getConsumerDetails();
			consumerDetails.setAgentName(jwtUtil.extractUsername(authorizationToken.substring(7)));
			businessDetails.setConsumerDetails(consumerBusiness.getConsumerDetails());
			int difference = (int) (businessDetails.getAnnualTurnover() - businessDetails.getCapitalInvested());
			final double profit = ((businessDetails.getAnnualTurnover() - businessDetails.getCapitalInvested()) / businessDetails.getCapitalInvested());
			final double profitPercentage = profit * 100;
			int roundedProfitPercentage = (int) profitPercentage;
			if (difference <= 0) {
				log.info("INSIDE ZERO");
				businessDetails.setIndexValue(indexValue);
			} else if (roundedProfitPercentage > 100) {
				log.info("INSIDE ROUNDED PROFIT PERCENTAGE");
				indexValue = 10;
				businessDetails.setIndexValue(indexValue);
			} else {
				log.info("INSIDE CALCULATING INDEX VALUE");
				indexValue = businessMasterRepository.findIndexValue(roundedProfitPercentage);
				businessDetails.setIndexValue(indexValue);
			}
			businessRepository.save(businessDetails);
			log.info("END OF CREATE CONSUMER BUSINESS SERVICE");
			return businessDetails;
		} else {
			throw new TokenInvalidException(TokenInvalidExceptionMessageConstants.INVALIDMESSAGE);
		}
	}

	/**
	 *@param propertyDetails
	 *@param id
	 *@param authorizationToken
	 *@return PropertyDetails
	 */
	@Override
	public PropertyDetails createBusinessProperty(PropertyDetails propertyDetails, Long id,
			String authorizationToken) throws Exception {
		log.info("INSIDE CREATE CONSUMER BUSINESS SERVICE");
		boolean valid = authenticationProxy.getValidity(authorizationToken).isValid();
		if (valid) {
			int age = propertyDetails.getPropertyAge();
			Integer indexValue;
			indexValue = propertyMasterRepository.findIndexValue(age);
			propertyDetails.setIndexValue(indexValue);
			Optional<BusinessDetails> businessDetailsOptional = businessRepository.findById(id);
			businessDetailsOptional.orElseThrow(() -> new BusinessNotFoundException("Business not found check the id"));
			propertyDetails.setBusinessDetails(businessDetailsOptional.get());
			propertyRepository.save(propertyDetails);
			log.info("END OF CREATE CONSUMER BUSINESS SERVICE");
			return propertyDetails;
		} else {
			throw new TokenInvalidException(TokenInvalidExceptionMessageConstants.INVALIDMESSAGE);
		}
	}

	/**
	 *@param businessId
	 *@param authorizationToken
	 *@throws TokenInvalidException
	 *@throws BusinessNotFoundException
	 */
	@Override
	public BusinessDetails viewConsumerBusiness(Long businessId, String authorizationToken)
			throws Exception {
		log.info("INISDE VIEW CONSUMER BUSINESS SERVICE");
		boolean valid = authenticationProxy.getValidity(authorizationToken).isValid();
		BusinessDetails businessDetails;
		if (valid) {
			try {
				businessDetails = businessRepository.findById(businessId).get();
			} catch (NoSuchElementException noSuchElementException) {
				throw new BusinessNotFoundException("Wrong Business ID");
			}
			log.info("END OF CONSUMER BUSINESS SERVICE");
			return businessDetails;
		} else {
			throw new TokenInvalidException(TokenInvalidExceptionMessageConstants.INVALIDMESSAGE);
		}
	}

	/**
	 *@param businessId
	 *@param propertyId
	 *@param authorizationToken
	 *@throws TokenInvalidException
	 *@throws PropertyNotFoundException
	 */
	@Override
	public PropertyDetails viewPropertyDetails(Long businessId, Long propertyId, String authorizationToken)
			throws Exception {
		log.info("INSIDE VIEW PROPERTY DETAILS SERVICE");
		boolean valid = authenticationProxy.getValidity(authorizationToken).isValid();
		if (valid) {
			PropertyDetails propertyDetails = propertyRepository.findByBusinessIdandPropertyId(businessId, propertyId);
			if (propertyDetails == null)
				throw new PropertyNotFoundException("Wrong Property ID or Busines ID");
			log.info("END OF VIEW PROPERTY DETAILS SERVICE");
			return propertyDetails;
		} else {
			throw new TokenInvalidException(TokenInvalidExceptionMessageConstants.INVALIDMESSAGE);
		}
	}

	/**
	 *@param consumerId
	 *@param consumerBusiness
	 *@param authorizationToken
	 *@return nothing
	 */
	@Override
	public void updateConsumerBusiness(Long consumerId, ConsumerBusiness consumerBusiness, String authorizationToken)
			throws Exception {
		log.info("INSIDE UPDATE CONSUMER BUSINESS SERVICE");
		boolean valid = authenticationProxy.getValidity(authorizationToken).isValid();
		if (valid) {
			BusinessDetails businessDetails;
			try {
				businessDetails = businessRepository.findById(consumerId).get();
			} catch (NoSuchElementException noSuchElementException) {
				throw new BusinessNotFoundException("Wrong Business ID");
			}
			ConsumerDetails consumerDetails = businessDetails.getConsumerDetails();
			businessDetails.setAnnualTurnover(consumerBusiness.getBusinessDetails().getAnnualTurnover());
			businessDetails.setBusinessDescription(consumerBusiness.getBusinessDetails().getBusinessDescription());
			businessDetails.setBusinessType(consumerBusiness.getBusinessDetails().getBusinessType());
			businessDetails.setTotalNoOfEmployees(consumerBusiness.getBusinessDetails().getTotalNoOfEmployees());
			consumerDetails.setBusinessOverview(consumerBusiness.getConsumerDetails().getBusinessOverview());
			consumerDetails.setDateOfBirth(consumerBusiness.getConsumerDetails().getDateOfBirth());
			consumerDetails.setEmail(consumerBusiness.getConsumerDetails().getEmail());
			consumerDetails.setName(consumerBusiness.getConsumerDetails().getName());
			consumerDetails.setPanNumber(consumerBusiness.getConsumerDetails().getPanNumber());
			consumerDetails.setValidity(consumerBusiness.getConsumerDetails().getValidity());
			consumerDetails.setBusinessDetails(businessDetails);
			businessRepository.save(businessDetails);
			log.info("END OF UPDATE CONSUMER BUSINESS SERVICE");

		} else {
			throw new TokenInvalidException(TokenInvalidExceptionMessageConstants.INVALIDMESSAGE);
		}
	}

	/**
	 *@param businessId
	 *@param propertyId
	 *@param propertyDetails
	 *@return nothing
	 */
	@Override
	public void updateBusinessProperty(Long businessId, Long propertyId, PropertyDetails propertyDetails,
			String authorizationToken) throws Exception {
		log.info("INSIDE UPDATE CONSUMER BUSINESS PROPERTY");
		boolean valid = authenticationProxy.getValidity(authorizationToken).isValid();
		if (valid) {
			PropertyDetails existingPropertyDetails = propertyRepository.findByBusinessIdandPropertyId(businessId,
					propertyId);

			if (existingPropertyDetails == null)
				throw new PropertyNotFoundException("Wrong Property ID or Busines ID");
			else {
				int indexValue = propertyMasterRepository.findIndexValue(propertyDetails.getPropertyAge());
				existingPropertyDetails.setPropertyAge(propertyDetails.getPropertyAge());
				existingPropertyDetails.setIndexValue(indexValue);
				existingPropertyDetails.setPropertySquarefeet(propertyDetails.getPropertySquarefeet());
				existingPropertyDetails.setPropertyStorey(propertyDetails.getPropertyStorey());
				existingPropertyDetails.setPropertyType(propertyDetails.getPropertyType());
				propertyRepository.save(existingPropertyDetails);
			}
			log.info("END OF UPDATE CONSUMER BUSINESS PROPERTY");
		} else {
			throw new TokenInvalidException(TokenInvalidExceptionMessageConstants.INVALIDMESSAGE);
		}
	}
}