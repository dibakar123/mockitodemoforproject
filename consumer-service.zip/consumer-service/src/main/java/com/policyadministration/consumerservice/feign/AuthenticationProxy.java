package com.policyadministration.consumerservice.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.policyadministration.consumerservice.model.AuthResponse;
import com.policyadministration.consumerservice.model.ValidationResponse;

/**Interface to connect with authentication service*/
@FeignClient(name = "${authentication.feign.client.name}", url = "${authentication.feign.client.url}")
public interface AuthenticationProxy 
{
	/**
	 * @param token
	 * @return ValidationResponse
	 */
	//@GetMapping("/validate")
	//public ValidationResponse validateUser(@RequestHeader("Authorization") final String token);
	@RequestMapping(value = "/validate", method = RequestMethod.GET)
	public AuthResponse getValidity(@RequestHeader("Authorization") final String token) throws Exception;
}