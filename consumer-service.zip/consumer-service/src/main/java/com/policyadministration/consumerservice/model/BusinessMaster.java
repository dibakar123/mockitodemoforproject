package com.policyadministration.consumerservice.model;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class BusinessMaster 
{
	/**
	 * Id of the entity
	 */
	@Id
	private Integer id;
	/**
	 *minimum profit percent 
	 */
	private Integer minPercent;
	/**
	 * maximum profit percent
	 */
	private Integer maxPercent;
	/**
	 * Index value of the business 
	 */
	private Integer index;
}