package com.policyadministration.consumerservice.exception;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.policyadministration.consumerservice.model.ConstraintErrorResponse;
import com.policyadministration.consumerservice.model.ErrorResponse;

/**Class to handle all the exceptions*/
@RestControllerAdvice
public class GlobalExceptionHandler 
{
	/**
	 * @param businessNotFoundException
	 * @return ErrorResponse
	 */
	@ExceptionHandler(BusinessNotFoundException.class)
	@ResponseStatus(HttpStatus.NOT_FOUND)
	public ErrorResponse businessValueNotEnoughException(BusinessNotFoundException businessNotFoundException) 
	{
		return new ErrorResponse(HttpStatus.NOT_FOUND, LocalDateTime.now(), businessNotFoundException.getMessage());
	}
	/**
	 * @param propertyNotFoundException
	 * @return ErrorResponse
	 */
	@ExceptionHandler(PropertyNotFoundException.class)
	@ResponseStatus(HttpStatus.NOT_FOUND)
	public ErrorResponse propertyValueNotEnoughException(PropertyNotFoundException propertyNotFoundException) 
	{
		return new ErrorResponse(HttpStatus.NOT_FOUND, LocalDateTime.now(), propertyNotFoundException.getMessage());
	}
	/**
	 * @return ErrorResponse
	 */
	@ExceptionHandler(feign.RetryableException.class)
	@ResponseStatus(HttpStatus.SERVICE_UNAVAILABLE)
	public ErrorResponse serviceUnavailableException() 
	{
		return new ErrorResponse(HttpStatus.SERVICE_UNAVAILABLE, LocalDateTime.now(), "Temporarily service unavailable");
	}
	/**
	 * @param constraintViolationException
	 * @return ResponseEntity
	 */
	@ExceptionHandler(ConstraintViolationException.class)
	@ResponseStatus(code = HttpStatus.BAD_REQUEST)
	public ResponseEntity<?> constraintValidationException(ConstraintViolationException constraintViolationException)
	{
		List<String> errorMessages = new ArrayList<String>();
		for(ConstraintViolation<?> constraintViolation:constraintViolationException.getConstraintViolations()) 
		{
			errorMessages.add(constraintViolation.getPropertyPath()+":"+constraintViolation.getMessage()+",Value given by you is "+constraintViolation.getInvalidValue());
		}
		return ResponseEntity.badRequest().body(new ConstraintErrorResponse(HttpStatus.BAD_REQUEST,LocalDateTime.now(),errorMessages));
		
	}
	/**
	 * @param numberFormatException
	 * @return ResponseEntity
	 */
	@ExceptionHandler(NumberFormatException.class)
	@ResponseStatus(code = HttpStatus.BAD_REQUEST)
	public ResponseEntity<?> methodArgumentMismatchException(NumberFormatException numberFormatException)
	{
		return ResponseEntity.badRequest().body(new ErrorResponse(HttpStatus.BAD_REQUEST, LocalDateTime.now()
				, "ID must be number"));
		}
	/**
	 * @param tokenInvalidException
	 * @return ResponseEntity
	 */
	@ExceptionHandler(TokenInvalidException.class)
	public ResponseEntity<Object> invalidExceptionHandler(TokenInvalidException tokenInvalidException) {
		return ResponseEntity.badRequest().body(new ErrorResponse(HttpStatus.BAD_REQUEST, LocalDateTime.now()
				, tokenInvalidException.getMessage()));
	}
}