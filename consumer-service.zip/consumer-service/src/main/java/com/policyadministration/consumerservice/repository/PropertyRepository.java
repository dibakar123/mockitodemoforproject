package com.policyadministration.consumerservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.policyadministration.consumerservice.model.PropertyDetails;

/**JPA Repository which interacts with database*/
@Repository
public interface PropertyRepository extends JpaRepository<PropertyDetails, Long> 
{
	/**
	 * @param businessId
	 * @param propertyId
	 * @return PropertyDetails
	 */
	@Query(value = "select p from PropertyDetails p where p.businessDetails.businessId = ?1 and p.propertyId = ?2")
	public PropertyDetails findByBusinessIdandPropertyId(Long businessId,Long propertyId);
}