package com.policyadministration.consumerservice.model;

import java.sql.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnore;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**Entity class to hold consumer details*/
@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class ConsumerDetails 
{
	/**Id of the consumer*/
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long consumerId;
	/**Name of the consumer*/
	@NotEmpty(message = "Consumer Name canot be empty")
	@Pattern(regexp = "[A-z]+",message = "Consumer name must be a word")
	@Size(min = 1,max = 20)
	private String name;
	/**Date of birth of the consumer*/
	private Date dateOfBirth;
	/**E-mail of the consumer*/
	@Email(message = "Email should be valid")
	private String email;
	/**Pan number of the consumer*/
	@NotNull(message = "Pan Number cannot not be empty")
	private String panNumber;
	/**Overview of the consumer business*/
	@NotEmpty(message = "Business overview canot be empty")
	private String businessOverview;
	/**validity of the consumer*/
	private int validity;
	/**Name of the agent who insure the business property*/
	private String agentName;
	/**Object which holds the business details of the consumer*/
	@OneToOne(mappedBy = "consumerDetails",cascade = CascadeType.ALL)
	@JsonIgnore
	private BusinessDetails businessDetails;
}