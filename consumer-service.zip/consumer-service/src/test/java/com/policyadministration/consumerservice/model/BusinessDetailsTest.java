package com.policyadministration.consumerservice.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class BusinessDetailsTest {

	BusinessDetails businessDetailsOne = new BusinessDetails();
	BusinessDetails businessDetailsTwo = new BusinessDetails(123L,"IT","Corporate",(double)12500,25L,(double)123000,0,null);
	
	@Test
	public void testBid()
	{
		businessDetailsOne.setBusinessId(123L);
		assertEquals(businessDetailsOne.getBusinessId(), 123L);
	}
	
	@Test
	public void testBdes()
	{
		businessDetailsOne.setBusinessDescription("IT");
		assertEquals(businessDetailsOne.getBusinessDescription(), "IT");
	}
	@Test
	public void testBType()
	{
		businessDetailsOne.setBusinessType("Corporate");;
		assertEquals(businessDetailsOne.getBusinessType(),"Corporate");
	}
	
	@Test
	public void testAnnuturnover()
	{
		businessDetailsOne.setAnnualTurnover((double)12500);
		assertEquals(businessDetailsOne.getAnnualTurnover(),(double)12500);
	}
	@Test
	public void testTotalno()
	{
		businessDetailsOne.setTotalNoOfEmployees(25L);
		assertEquals(businessDetailsOne.getTotalNoOfEmployees(),25L);
	}
	
	@Test
	public void testCapital()
	{
		businessDetailsOne.setCapitalInvested((double)123000);
		assertEquals(businessDetailsOne.getCapitalInvested(), (double)123000);
	}

	@Test
	public void testIndex()
	{
		businessDetailsOne.setIndexValue(5);
		assertEquals(businessDetailsOne.getIndexValue(),5);
	}
	
	@Test
	public void testConsumerDetails()
	{
		businessDetailsOne.setConsumerDetails(null);
		assertEquals(businessDetailsOne.getConsumerDetails(),null);
	}
	
	@Test
	public void testToString()
	{
		String expected = businessDetailsTwo.toString();
		assertEquals(expected,businessDetailsTwo.toString());
	}
}