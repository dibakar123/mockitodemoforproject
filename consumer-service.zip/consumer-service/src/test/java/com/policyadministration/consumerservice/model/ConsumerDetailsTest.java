package com.policyadministration.consumerservice.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;


public class ConsumerDetailsTest 
{
	
	
	ConsumerDetails consumerDetailsOne=new ConsumerDetails();
	ConsumerDetails consumerDetailsTwo=new ConsumerDetails(12L,"Martin",null,"xyz@gmail.com","pan123","Good",12,"123agent",null);
	
	
	@Test
	public void testConsumerId()
	{
		consumerDetailsOne.setConsumerId(12L);
		assertEquals(consumerDetailsOne.getConsumerId(), 12L);
	}
	@Test
	public void testConsumerName()
	{
		consumerDetailsOne.setName("hi");
		assertEquals(consumerDetailsOne.getName(), "hi");
	}
	@Test
	public void testDob()
	{
		consumerDetailsOne.setDateOfBirth(null);;
		assertEquals(consumerDetailsOne.getDateOfBirth(), null);
	}
	@Test
	public void testEmail()
	{
		consumerDetailsOne.setEmail("xyz@gmail.com");;
		assertEquals(consumerDetailsOne.getEmail(), "xyz@gmail.com");
	}
	@Test
	public void testPanNumber()
	{
		consumerDetailsOne.setPanNumber("pan123");;
		assertEquals(consumerDetailsOne.getPanNumber(), "pan123");
	}
	@Test
	public void testBusinessOverview()
	{
		consumerDetailsOne.setBusinessOverview("Good");;
		assertEquals(consumerDetailsOne.getBusinessOverview(), "Good");
	}
	@Test
	public void testValidity()
	{
		consumerDetailsOne.setValidity(12);
		assertEquals(consumerDetailsOne.getValidity(), 12);
	}

	@Test
	public void testAgentName()
	{
		consumerDetailsOne.setAgentName("123Agent");
		assertEquals(consumerDetailsOne.getAgentName(), "123Agent");
	}
	@Test
	public void testBusinessDetails()
	{
		consumerDetailsOne.setBusinessDetails(null);
		assertEquals(consumerDetailsOne.getBusinessDetails(), null);
	}
	@Test
	public void toStringTest() 
	{
		String expected = consumerDetailsTwo.toString();
		assertEquals(expected, consumerDetailsTwo.toString());
	}
}