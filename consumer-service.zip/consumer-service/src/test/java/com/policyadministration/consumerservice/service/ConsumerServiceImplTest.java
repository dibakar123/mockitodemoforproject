package com.policyadministration.consumerservice.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.sql.Date;
import java.time.LocalDate;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.policyadministration.consumerservice.exception.BusinessNotFoundException;
import com.policyadministration.consumerservice.exception.PropertyNotFoundException;
import com.policyadministration.consumerservice.exception.TokenInvalidException;
import com.policyadministration.consumerservice.feign.AuthenticationProxy;
import com.policyadministration.consumerservice.model.AuthResponse;
import com.policyadministration.consumerservice.model.BusinessDetails;
import com.policyadministration.consumerservice.model.ConsumerBusiness;
import com.policyadministration.consumerservice.model.ConsumerDetails;
import com.policyadministration.consumerservice.model.PropertyDetails;
import com.policyadministration.consumerservice.model.ValidationResponse;
import com.policyadministration.consumerservice.repository.BusinessMasterRepository;
import com.policyadministration.consumerservice.repository.BusinessRepository;
import com.policyadministration.consumerservice.repository.PropertyMasterRepository;
import com.policyadministration.consumerservice.repository.PropertyRepository;
import com.policyadministration.consumerservice.util.JwtUtil;

@SpringBootTest
@AutoConfigureMockMvc
public class ConsumerServiceImplTest {
	@InjectMocks
	private ConsumerServiceImpl consumerServiceImp;

	@Mock
	private AuthenticationProxy authenticationProxy;

	@Mock
	private BusinessMasterRepository businessMasterRepository;

	@Mock
	private PropertyMasterRepository propertyMasterRepository;

	@Mock
	private BusinessRepository businessRepository;

	@Mock
	private PropertyRepository propertyRepository;

	@Mock
	private JwtUtil jwtUtil;

	@Test
	public void testCreateConsumer() throws Exception {
		//ValidationResponse authResponse = new ValidationResponse("Agent1", true);
		AuthResponse authResponse = new AuthResponse("admin","admin", true);
		String token = "Bearer token";
		when(authenticationProxy.getValidity(token)).thenReturn(authResponse);
		BusinessDetails businessDetails1 = new BusinessDetails(1L, "IT", "Corporate", (double) 20000, 100L,(double) 10000, 1,new ConsumerDetails(1L, "Digu", null, "xyz@gmail.com", "67ER3W", "Corporate", 3, "Agent1", null));
		ResponseEntity<BusinessDetails> business = new ResponseEntity((businessDetails1), HttpStatus.OK);
		ConsumerDetails counsumerDetails = new ConsumerDetails(1L, "Digu", Date.valueOf(LocalDate.now()),
				"xyz@gmail.com", "67ER3W", "Corporate", 3, "Agent1",
				new BusinessDetails(1L, "IT", "Corporate", (double) 20000, 100L, (double) 10000, 1, null));
		ConsumerBusiness consumerBusiness = new ConsumerBusiness(counsumerDetails, businessDetails1);
		when(jwtUtil.extractUsername(token)).thenReturn("Digu");
		assertEquals(business.getBody(), consumerServiceImp.createConsumerBusiness(consumerBusiness, token));
	}
	
	@Test
	public void testCreateConsumerZeroCase() throws Exception {
		//ValidationResponse authResponse = new ValidationResponse("Agent1", true);
		String token = "Bearer token";
		//when(authenticationProxy.validateUser(token)).thenReturn(authResponse);
		AuthResponse authResponse = new AuthResponse("admin","admin", true);
		when(authenticationProxy.getValidity(token)).thenReturn(authResponse);
		BusinessDetails businessDetails1 = new BusinessDetails(1L, "IT", "Corporate", (double) 20000, 100L,(double) 20000, 1,new ConsumerDetails(1L, "Digu", null, "xyz@gmail.com", "67ER3W", "Corporate", 3, "Agent1", null));
		ResponseEntity<BusinessDetails> business = new ResponseEntity((businessDetails1), HttpStatus.OK);
		ConsumerDetails counsumerDetails = new ConsumerDetails(1L, "Digu", Date.valueOf(LocalDate.now()),
				"xyz@gmail.com", "67ER3W", "Corporate", 3, "Agent1",
				new BusinessDetails(1L, "IT", "Corporate", (double) 20000, 100L, (double) 10000, 1, null));
		ConsumerBusiness consumerBusiness = new ConsumerBusiness(counsumerDetails, businessDetails1);
		when(jwtUtil.extractUsername(token)).thenReturn("Digu");
		assertEquals(business.getBody(), consumerServiceImp.createConsumerBusiness(consumerBusiness, token));
	}
	
	@Test
	public void testCreateConsumerGreaterthanMaxCase() throws Exception {
		//ValidationResponse authResponse = new ValidationResponse("Agent1", true);
		String token = "Bearer token";
		//when(authenticationProxy.validateUser(token)).thenReturn(authResponse);
		AuthResponse authResponse = new AuthResponse("admin","admin", true);
		when(authenticationProxy.getValidity(token)).thenReturn(authResponse);
		BusinessDetails businessDetails1 = new BusinessDetails(1L, "IT", "Corporate", (double) 2000000, 100L,(double) 20000, 1,new ConsumerDetails(1L, "Digu", null, "xyz@gmail.com", "67ER3W", "Corporate", 3, "Agent1", null));
		ResponseEntity<BusinessDetails> business = new ResponseEntity((businessDetails1), HttpStatus.OK);
		ConsumerDetails counsumerDetails = new ConsumerDetails(1L, "Digu", Date.valueOf(LocalDate.now()),
				"xyz@gmail.com", "67ER3W", "Corporate", 3, "Agent1",
				new BusinessDetails(1L, "IT", "Corporate", (double) 20000, 100L, (double) 10000, 1, null));
		ConsumerBusiness consumerBusiness = new ConsumerBusiness(counsumerDetails, businessDetails1);
		when(jwtUtil.extractUsername(token)).thenReturn("Digu");
		assertEquals(business.getBody(), consumerServiceImp.createConsumerBusiness(consumerBusiness, token));
	}
	
	@Test
	public void testCreateConsumerInvalidToken() throws Exception
	{
		//ValidationResponse authResponse = new ValidationResponse("Agent1", false);
		String token = "Bearer token";
		//when(authenticationProxy.validateUser(token)).thenReturn(authResponse);	
		AuthResponse authResponse = new AuthResponse("admin","admin", true);
		when(authenticationProxy.getValidity(token)).thenReturn(authResponse);
		BusinessDetails businessDetails1 = new BusinessDetails(1L, "IT", "Corporate", (double) 20000, 100L,(double) 10000, 1,new ConsumerDetails(1L, "Digu", null, "xyz@gmail.com", "67ER3W", "Corporate", 3, "Agent1", null));	
		ResponseEntity<BusinessDetails> business = new ResponseEntity((businessDetails1), HttpStatus.OK);
		ConsumerDetails counsumerDetails = new ConsumerDetails(1L, "Digu", Date.valueOf(LocalDate.now()),
				"xyz@gmail.com", "67ER3W", "Corporate", 3, "Agent1",
				new BusinessDetails(1L, "IT", "Corporate", (double) 20000, 100L, (double) 10000, 1, null));
		ConsumerBusiness consumerBusiness = new ConsumerBusiness(counsumerDetails, businessDetails1);	
		assertThrows(TokenInvalidException.class, () ->consumerServiceImp.createConsumerBusiness(consumerBusiness, token) );
	}
	
	@Test
	public void testCreateBusinessProperty() throws Exception
	{
		//ValidationResponse authResponse = new ValidationResponse("Agent1", true);
		String token = "Bearer token";
		//when(authenticationProxy.validateUser(token)).thenReturn(authResponse);
		AuthResponse authResponse = new AuthResponse("admin","admin", true);
		when(authenticationProxy.getValidity(token)).thenReturn(authResponse);
		BusinessDetails businessDetails1 = new BusinessDetails(1L, "IT", "Corporate", (double) 20000, 100L,
				(double) 10000, 1,
				new ConsumerDetails(1L, "Digu", null, "xyz@gmail.com", "67ER3W", "Corporate", 3, "Agent1", null));
		ConsumerDetails counsumerDetails = new ConsumerDetails(1L, "Digu", Date.valueOf(LocalDate.now()),
				"xyz@gmail.com", "67ER3W", "Corporate", 3, "Agent1",
				new BusinessDetails(1L, "IT", "Corporate", (double) 20000, 100L, (double) 10000, 1, null));
		PropertyDetails propertyDetailsTwo = new PropertyDetails(1L, 345L, "Land", 5, 3, 1,
				new BusinessDetails(1L, "IT", "Corporate", (double) 20000, 100L, (double) 10000, 1,
						new ConsumerDetails(1L, "Digu", Date.valueOf(LocalDate.now()), "xyz@gmail.com", "67ER3W",
								"Corporate", 3, "Agent1", null)));
		ResponseEntity<PropertyDetails> property = new ResponseEntity((propertyDetailsTwo), HttpStatus.OK);
		when(propertyMasterRepository.findIndexValue(5)).thenReturn(5);
		when(businessRepository.findById(1L)).thenReturn(Optional.of(businessDetails1));
		assertEquals(property.getBody(),consumerServiceImp.createBusinessProperty(propertyDetailsTwo, 1L, token));
	}

	@Test
	public void testBusinessPropertyInvalid() throws Exception{
		
		//ValidationResponse authResponse = new ValidationResponse("Agent1",false);
		String token = "Bearer token";
		//when(authenticationProxy.validateUser(token)).thenReturn(authResponse);
		AuthResponse authResponse = new AuthResponse("admin","admin", true);
		when(authenticationProxy.getValidity(token)).thenReturn(authResponse);
		BusinessDetails businessDetails1 = new BusinessDetails(1L, "IT", "Corporate", (double) 20000, 100L,
				(double) 10000, 1,
				new ConsumerDetails(1L, "Digu", null, "xyz@gmail.com", "67ER3W", "Corporate", 3, "Agent1", null));
		ConsumerDetails counsumerDetails = new ConsumerDetails(1L, "Digu", Date.valueOf(LocalDate.now()),
				"xyz@gmail.com", "67ER3W", "Corporate", 3, "Agent1",
				new BusinessDetails(1L, "IT", "Corporate", (double) 20000, 100L, (double) 10000, 1, null));
		PropertyDetails propertyDetailsTwo = new PropertyDetails(1L, 345L, "Land", 5, 3, 1,
				new BusinessDetails(1L, "IT", "Corporate", (double) 20000, 100L, (double) 10000, 1,
						new ConsumerDetails(1L, "Digu", Date.valueOf(LocalDate.now()), "xyz@gmail.com", "67ER3W",
								"Corporate", 3, "Agent1", null)));
		ResponseEntity<PropertyDetails> property = new ResponseEntity((propertyDetailsTwo), HttpStatus.OK);
		assertThrows(TokenInvalidException.class, () ->consumerServiceImp.createBusinessProperty(propertyDetailsTwo, 1L,token) );
	}
	
	@Test
	public void testViewConsumerBusiness() throws Exception {

		//ValidationResponse authResponse = new ValidationResponse("Agent1", true);
		String token = "Bearer token";
		//when(authenticationProxy.validateUser(token)).thenReturn(authResponse);
		AuthResponse authResponse = new AuthResponse("admin","admin", true);
		when(authenticationProxy.getValidity(token)).thenReturn(authResponse);
		BusinessDetails businessDetails1 = new BusinessDetails(1L, "IT", "Corporate", (double) 20000, 100L,
				(double) 10000, 1,
				new ConsumerDetails(1L, "Digu", null, "xyz@gmail.com", "67ER3W", "Corporate", 3, "Agent1", null));
		//ResponseEntity<BusinessDetails> business = new ResponseEntity((businessDetails1), HttpStatus.OK);
		ConsumerDetails counsumerDetails = new ConsumerDetails(1L, "Digu", Date.valueOf(LocalDate.now()),
				"xyz@gmail.com", "67ER3W", "Corporate", 3, "Agent1",
				new BusinessDetails(1L, "IT", "Corporate", (double) 20000, 100L, (double) 10000, 1, null));
		ConsumerBusiness consumerBusiness = new ConsumerBusiness(counsumerDetails, businessDetails1);
		when(businessRepository.findById(1L)).thenReturn(Optional.of(businessDetails1));
		assertEquals(businessDetails1, consumerServiceImp.viewConsumerBusiness(1L, token));

	}
	@Test
	public void testViewConsumerBusinessNotFound() throws Exception {

		//ValidationResponse authResponse = new ValidationResponse("Agent1", true);
		String token = "Bearer token";
		//when(authenticationProxy.validateUser(token)).thenReturn(authResponse);
		AuthResponse authResponse = new AuthResponse("admin","admin", true);
		when(authenticationProxy.getValidity(token)).thenReturn(authResponse);
		BusinessDetails businessDetails1 = new BusinessDetails(1L, "IT", "Corporate", (double) 20000, 100L,
				(double) 10000, 1,
				new ConsumerDetails(1L, "Digu", null, "xyz@gmail.com", "67ER3W", "Corporate", 3, "Agent1", null));
		ResponseEntity<BusinessDetails> business = new ResponseEntity((businessDetails1), HttpStatus.OK);
		ConsumerDetails counsumerDetails = new ConsumerDetails(1L, "Digu", Date.valueOf(LocalDate.now()),
				"xyz@gmail.com", "67ER3W", "Corporate", 3, "Agent1",
				new BusinessDetails(1L, "IT", "Corporate", (double) 20000, 100L, (double) 10000, 1, null));
		ConsumerBusiness consumerBusiness = new ConsumerBusiness(counsumerDetails, businessDetails1);
		when(businessRepository.findById(3L)).thenReturn(Optional.of(businessDetails1));
		assertThrows(BusinessNotFoundException.class, () ->consumerServiceImp.viewConsumerBusiness(1L, token) );

	}
	
	@Test
	public void testViewConsumerBusinessNotFoundProperty() throws Exception {

		//ValidationResponse authResponse = new ValidationResponse("Agent1", true);

		String token = "Bearer token";
		//when(authenticationProxy.validateUser(token)).thenReturn(authResponse);
		AuthResponse authResponse = new AuthResponse("admin","admin", true);
		when(authenticationProxy.getValidity(token)).thenReturn(authResponse);
		BusinessDetails businessDetails1 = new BusinessDetails(1L, "IT", "Corporate", (double) 20000, 100L,
				(double) 10000, 1,
				new ConsumerDetails(1L, "Digu", null, "xyz@gmail.com", "67ER3W", "Corporate", 3, "Agent1", null));
		ResponseEntity<BusinessDetails> business = new ResponseEntity((businessDetails1), HttpStatus.OK);
		ConsumerDetails counsumerDetails = new ConsumerDetails(1L, "Digu", Date.valueOf(LocalDate.now()),
				"xyz@gmail.com", "67ER3W", "Corporate", 3, "Agent1",
				new BusinessDetails(1L, "IT", "Corporate", (double) 20000, 100L, (double) 10000, 1, null));
		PropertyDetails propertyDetails = new PropertyDetails(1L, 345L, "Land", 5, 3, 1,
				new BusinessDetails(1L, "IT", "Corporate", (double) 20000, 100L, (double) 10000, 1,
						new ConsumerDetails(1L, "Digu", Date.valueOf(LocalDate.now()), "xyz@gmail.com", "67ER3W",
								"Corporate", 3, "Agent1", null)));
		ConsumerBusiness consumerBusiness = new ConsumerBusiness(counsumerDetails, businessDetails1);
		when(businessRepository.findById(3L)).thenReturn(Optional.of(businessDetails1));
		assertThrows(BusinessNotFoundException.class, () ->consumerServiceImp.createBusinessProperty(propertyDetails, 12L, token));

	}
	@Test
	public void testViewConsumerBusinessInvalidToken() throws Exception {
		//ValidationResponse authResponse = new ValidationResponse("Agent1", false);
		String token = "Bearer token";
		//when(authenticationProxy.validateUser(token)).thenReturn(authResponse);
		AuthResponse authResponse = new AuthResponse("admin","admin", true);
		when(authenticationProxy.getValidity(token)).thenReturn(authResponse);
		BusinessDetails businessDetails1 = new BusinessDetails(1L, "IT", "Corporate", (double) 20000, 100L,
				(double) 10000, 1,
				new ConsumerDetails(1L, "Digu", null, "xyz@gmail.com", "67ER3W", "Corporate", 3, "Agent1", null));
		ResponseEntity<BusinessDetails> business = new ResponseEntity((businessDetails1), HttpStatus.OK);
		ConsumerDetails counsumerDetails = new ConsumerDetails(1L, "Digu", Date.valueOf(LocalDate.now()),
				"xyz@gmail.com", "67ER3W", "Corporate", 3, "Agent1",
				new BusinessDetails(1L, "IT", "Corporate", (double) 20000, 100L, (double) 10000, 1, null));
		ConsumerBusiness consumerBusiness = new ConsumerBusiness(counsumerDetails, businessDetails1);
		assertThrows(TokenInvalidException.class, () ->consumerServiceImp.viewConsumerBusiness(1L, token) );
	}

	@Test
	public void testViewPropertyDetails() throws Exception {
		//ValidationResponse authResponse = new ValidationResponse("Agent1", true);
		String token = "Bearer token";
		//when(authenticationProxy.validateUser(token)).thenReturn(authResponse);
		AuthResponse authResponse = new AuthResponse("admin","admin", true);
		when(authenticationProxy.getValidity(token)).thenReturn(authResponse);
		BusinessDetails businessDetails1 = new BusinessDetails(1L, "IT", "Corporate", (double) 20000, 100L,
				(double) 10000, 1,
				new ConsumerDetails(1L, "Digu", null, "xyz@gmail.com", "67ER3W", "Corporate", 3, "Agent1", null));
		ConsumerDetails counsumerDetails = new ConsumerDetails(1L, "Digu", Date.valueOf(LocalDate.now()),
				"xyz@gmail.com", "67ER3W", "Corporate", 3, "Agent1",
				new BusinessDetails(1L, "IT", "Corporate", (double) 20000, 100L, (double) 10000, 1, null));
		PropertyDetails propertyDetailsTwo = new PropertyDetails(1L, 345L, "Land", 5, 3, 1,
				new BusinessDetails(1L, "IT", "Corporate", (double) 20000, 100L, (double) 10000, 1,
						new ConsumerDetails(1L, "Digu", Date.valueOf(LocalDate.now()), "xyz@gmail.com", "67ER3W",
								"Corporate", 3, "Agent1", null)));
		when(propertyRepository.findByBusinessIdandPropertyId(1L, 1L)).thenReturn(propertyDetailsTwo);
		assertEquals(propertyDetailsTwo, consumerServiceImp.viewPropertyDetails(1L, 1L, token));

	}
	@Test
	public void testViewPropertyDetailsNOtFound() throws Exception {
		//ValidationResponse authResponse = new ValidationResponse("Agent1", true);
		String token = "Bearer token";
		//when(authenticationProxy.validateUser(token)).thenReturn(authResponse);
		AuthResponse authResponse = new AuthResponse("admin","admin", true);
		when(authenticationProxy.getValidity(token)).thenReturn(authResponse);
		BusinessDetails businessDetails1 = new BusinessDetails(1L, "IT", "Corporate", (double) 20000, 100L,
				(double) 10000, 1,
				new ConsumerDetails(1L, "Digu", null, "xyz@gmail.com", "67ER3W", "Corporate", 3, "Agent1", null));
		ConsumerDetails counsumerDetails = new ConsumerDetails(1L, "Digu", Date.valueOf(LocalDate.now()),
				"xyz@gmail.com", "67ER3W", "Corporate", 3, "Agent1",
				new BusinessDetails(1L, "IT", "Corporate", (double) 20000, 100L, (double) 10000, 1, null));
		PropertyDetails propertyDetailsTwo = new PropertyDetails(1L, 345L, "Land", 5, 3, 1,
				new BusinessDetails(1L, "IT", "Corporate", (double) 20000, 100L, (double) 10000, 1,
						new ConsumerDetails(1L, "Digu", Date.valueOf(LocalDate.now()), "xyz@gmail.com", "67ER3W",
								"Corporate", 3, "Agent1", null)));
		when(propertyRepository.findByBusinessIdandPropertyId(1L, 1L)).thenReturn(propertyDetailsTwo);
		assertThrows(PropertyNotFoundException.class, () ->consumerServiceImp.viewPropertyDetails(2L, 1L, token));
	}
	
	@Test
	public void testViewBusinessPropertyInvalidToken() throws Exception{
		//ValidationResponse authResponse = new ValidationResponse("Agent1", false);
		String token = "Bearer token";
		//when(authenticationProxy.validateUser(token)).thenReturn(authResponse);
		AuthResponse authResponse = new AuthResponse("admin","admin", true);
		when(authenticationProxy.getValidity(token)).thenReturn(authResponse);
		BusinessDetails businessDetails1 = new BusinessDetails(1L, "IT", "Corporate", (double) 20000, 100L,
				(double) 10000, 1,
				new ConsumerDetails(1L, "Digu", null, "xyz@gmail.com", "67ER3W", "Corporate", 3, "Agent1", null));
		ConsumerDetails counsumerDetails = new ConsumerDetails(1L, "Digu", Date.valueOf(LocalDate.now()),
				"xyz@gmail.com", "67ER3W", "Corporate", 3, "Agent1",
				new BusinessDetails(1L, "IT", "Corporate", (double) 20000, 100L, (double) 10000, 1, null));
		PropertyDetails propertyDetailsTwo = new PropertyDetails(1L, 345L, "Land", 5, 3, 1,
				new BusinessDetails(1L, "IT", "Corporate", (double) 20000, 100L, (double) 10000, 1,
						new ConsumerDetails(1L, "Digu", Date.valueOf(LocalDate.now()), "xyz@gmail.com", "67ER3W",
								"Corporate", 3, "Agent1", null)));
		assertThrows(TokenInvalidException.class, () ->consumerServiceImp.viewPropertyDetails(1L, 1L, token) );
		
	}

	@Test
	public void testUpdateConsumerBusiness() throws Exception {
		//ValidationResponse authResponse = new ValidationResponse("Agent1", true);
		String token = "Bearer token";
		//when(authenticationProxy.validateUser(token)).thenReturn(authResponse);
		AuthResponse authResponse = new AuthResponse("admin","admin", true);
		when(authenticationProxy.getValidity(token)).thenReturn(authResponse);
		BusinessDetails businessDetails1 = new BusinessDetails(1L, "IT", "Corporate", (double) 20000, 100L,
				(double) 10000, 1,
				new ConsumerDetails(1L, "Digu", null, "xyz@gmail.com", "67ER3W", "Corporate", 3, "Agent1", null));
		ConsumerDetails counsumerDetails = new ConsumerDetails(1L, "Digu", Date.valueOf(LocalDate.now()),
				"xyz@gmail.com", "67ER3W", "Corporate", 3, "Agent1",
				new BusinessDetails(1L, "IT", "Corporate", (double) 20000, 100L, (double) 10000, 1, null));
		ConsumerBusiness consumerBusiness = new ConsumerBusiness(counsumerDetails, businessDetails1);
		when(businessRepository.findById(1L)).thenReturn(Optional.of(businessDetails1));
		consumerServiceImp.updateConsumerBusiness(1L, consumerBusiness, token);
		
		
	}
	
	@Test
	public void testUpdateConsumerBusinessNotFound() throws Exception {
		//ValidationResponse authResponse = new ValidationResponse("Agent1", true);

		String token = "Bearer token";
		//when(authenticationProxy.validateUser(token)).thenReturn(authResponse);
		AuthResponse authResponse = new AuthResponse("admin","admin", true);
		when(authenticationProxy.getValidity(token)).thenReturn(authResponse);
		BusinessDetails businessDetails1 = new BusinessDetails(1L, "IT", "Corporate", (double) 20000, 100L,
				(double) 10000, 1,
				new ConsumerDetails(1L, "Digu", null, "xyz@gmail.com", "67ER3W", "Corporate", 3, "Agent1", null));
		ConsumerDetails counsumerDetails = new ConsumerDetails(1L, "Digu", Date.valueOf(LocalDate.now()),
				"xyz@gmail.com", "67ER3W", "Corporate", 3, "Agent1",
				new BusinessDetails(1L, "IT", "Corporate", (double) 20000, 100L, (double) 10000, 1, null));
		ConsumerBusiness consumerBusiness = new ConsumerBusiness(counsumerDetails, businessDetails1);
		when(businessRepository.findById(1L)).thenReturn(Optional.of(businessDetails1));
		consumerServiceImp.updateConsumerBusiness(1L, consumerBusiness, token);
		assertThrows(BusinessNotFoundException.class, () ->consumerServiceImp.updateConsumerBusiness(2L, consumerBusiness, token) );
		
		
	}
	@Test
	public void testUpdateConsumerBusinessInvalidToken() throws Exception
	{
		//ValidationResponse authResponse = new ValidationResponse("Agent1", false);
		String token = "Bearer token";
		//when(authenticationProxy.validateUser(token)).thenReturn(authResponse);
		AuthResponse authResponse = new AuthResponse("admin","admin", true);
		when(authenticationProxy.getValidity(token)).thenReturn(authResponse);
		BusinessDetails businessDetails1 = new BusinessDetails(1L, "IT", "Corporate", (double) 20000, 100L,
				(double) 10000, 1,
				new ConsumerDetails(1L, "Digu", null, "xyz@gmail.com", "67ER3W", "Corporate", 3, "Agent1", null));
		ConsumerDetails counsumerDetails = new ConsumerDetails(1L, "Digu", Date.valueOf(LocalDate.now()),
				"xyz@gmail.com", "67ER3W", "Corporate", 3, "Agent1",
				new BusinessDetails(1L, "IT", "Corporate", (double) 20000, 100L, (double) 10000, 1, null));
		ConsumerBusiness consumerBusiness = new ConsumerBusiness(counsumerDetails, businessDetails1);
		assertThrows(TokenInvalidException.class, () ->consumerServiceImp.updateConsumerBusiness(1L, consumerBusiness, token));
	}

	@Test
	public void testUpdateBusinessProperty() throws Exception {
		//ValidationResponse authResponse = new ValidationResponse("Agent1", true);
		String token = "Bearer token";
		//when(authenticationProxy.validateUser(token)).thenReturn(authResponse);
		AuthResponse authResponse = new AuthResponse("admin","admin", true);
		when(authenticationProxy.getValidity(token)).thenReturn(authResponse);
		BusinessDetails businessDetails1 = new BusinessDetails(1L, "IT", "Corporate", (double) 20000, 100L,
				(double) 10000, 1,
				new ConsumerDetails(1L, "Digu", null, "xyz@gmail.com", "67ER3W", "Corporate", 3, "Agent1", null));
		ConsumerDetails counsumerDetails = new ConsumerDetails(1L, "Digu", Date.valueOf(LocalDate.now()),
				"xyz@gmail.com", "67ER3W", "Corporate", 3, "Agent1",
				new BusinessDetails(1L, "IT", "Corporate", (double) 20000, 100L, (double) 10000, 1, null));
		PropertyDetails propertyDetailsTwo = new PropertyDetails(1L, 345L, "Land", 5, 3, 1,
				new BusinessDetails(1L, "IT", "Corporate", (double) 20000, 100L, (double) 10000, 1,
						new ConsumerDetails(1L, "Digu", Date.valueOf(LocalDate.now()), "xyz@gmail.com", "67ER3W",
								"Corporate", 3, "Agent1", null)));
		when(propertyRepository.findByBusinessIdandPropertyId(1L, 1L)).thenReturn(propertyDetailsTwo);
		when(propertyMasterRepository.findIndexValue(3)).thenReturn(3);
		consumerServiceImp.updateBusinessProperty(1L, 1L, propertyDetailsTwo, token);

	}
	
	@Test
	public void testUpdateBusinessPropertyNotFound() throws Exception {
		//ValidationResponse authResponse = new ValidationResponse("Agent1", true);
		String token = "Bearer token";
		//when(authenticationProxy.validateUser(token)).thenReturn(authResponse);
		AuthResponse authResponse = new AuthResponse("admin","admin", true);
		when(authenticationProxy.getValidity(token)).thenReturn(authResponse);
		BusinessDetails businessDetails1 = new BusinessDetails(1L, "IT", "Corporate", (double) 20000, 100L,
				(double) 10000, 1,
				new ConsumerDetails(1L, "Digu", null, "xyz@gmail.com", "67ER3W", "Corporate", 3, "Agent1", null));
		ConsumerDetails counsumerDetails = new ConsumerDetails(1L, "Digu", Date.valueOf(LocalDate.now()),
				"xyz@gmail.com", "67ER3W", "Corporate", 3, "Agent1",
				new BusinessDetails(1L, "IT", "Corporate", (double) 20000, 100L, (double) 10000, 1, null));
		PropertyDetails propertyDetailsTwo = new PropertyDetails(1L, 345L, "Land", 5, 3, 1,
				new BusinessDetails(1L, "IT", "Corporate", (double) 20000, 100L, (double) 10000, 1,
						new ConsumerDetails(1L, "Digu", Date.valueOf(LocalDate.now()), "xyz@gmail.com", "67ER3W",
								"Corporate", 3, "Agent1", null)));
		when(propertyRepository.findByBusinessIdandPropertyId(1L, 1L)).thenReturn(propertyDetailsTwo);
		when(propertyMasterRepository.findIndexValue(3)).thenReturn(3);
		consumerServiceImp.updateBusinessProperty(1L, 1L, propertyDetailsTwo, token);
		assertThrows(PropertyNotFoundException.class, () ->consumerServiceImp.updateBusinessProperty(2L, 1L, propertyDetailsTwo, token));
	}
	
	
	@Test 
	public void testUpdateBusinessPropertyInvalidToken() throws Exception{
		//ValidationResponse authResponse = new ValidationResponse("Agent1", false);

		String token = "Bearer token";
		//when(authenticationProxy.validateUser(token)).thenReturn(authResponse);
		AuthResponse authResponse = new AuthResponse("admin","admin", true);
		when(authenticationProxy.getValidity(token)).thenReturn(authResponse);
		BusinessDetails businessDetails1 = new BusinessDetails(1L, "IT", "Corporate", (double) 20000, 100L,
				(double) 10000, 1,
				new ConsumerDetails(1L, "Digu", null, "xyz@gmail.com", "67ER3W", "Corporate", 3, "Agent1", null));
		ConsumerDetails counsumerDetails = new ConsumerDetails(1L, "Digu", Date.valueOf(LocalDate.now()),
				"xyz@gmail.com", "67ER3W", "Corporate", 3, "Agent1",
				new BusinessDetails(1L, "IT", "Corporate", (double) 20000, 100L, (double) 10000, 1, null));

		PropertyDetails propertyDetailsTwo = new PropertyDetails(1L, 345L, "Land", 5, 3, 1,
				new BusinessDetails(1L, "IT", "Corporate", (double) 20000, 100L, (double) 10000, 1,
						new ConsumerDetails(1L, "Digu", Date.valueOf(LocalDate.now()), "xyz@gmail.com", "67ER3W",
								"Corporate", 3, "Agent1", null)));
		assertThrows(TokenInvalidException.class, () ->consumerServiceImp.updateBusinessProperty(1L, 1L, propertyDetailsTwo, token));
	}
	
	

}
