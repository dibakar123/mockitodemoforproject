package com.policyadministration.consumerservice.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

public class PropertyDetailsTest {
	PropertyDetails propertyDetailsOne = new PropertyDetails();
	PropertyDetails propertyDetailsTwo = new PropertyDetails(123L, 345L, "Corporate", 5, 4, 0, null);

	@Test
	public void testPropertyId() {
		propertyDetailsOne.setPropertyId(123L);
		assertEquals(propertyDetailsOne.getPropertyId(), 123L);

	}

	@Test
	public void testPropertySquareFeet() {
		propertyDetailsOne.setPropertySquarefeet(345L);
		assertEquals(propertyDetailsOne.getPropertySquarefeet(), 345L);
	}

	@Test
	public void testPropertyType() {
		propertyDetailsOne.setPropertyType("Corporate");
		assertEquals(propertyDetailsOne.getPropertyType(), "Corporate");
	}

	@Test
	public void testPropertyStorey() {
		propertyDetailsOne.setPropertyStorey(5);
		assertEquals(propertyDetailsOne.getPropertyStorey(), 5);
	}

	@Test
	public void testPropertyAge() {
		propertyDetailsOne.setPropertyAge(4);
		assertEquals(propertyDetailsOne.getPropertyAge(), 4);
	}

	@Test
	public void testIndexValue() {
		propertyDetailsOne.setIndexValue(0);
		assertEquals(propertyDetailsOne.getIndexValue(), 0);
	}

	@Test
	public void testBusinessDetails() {
		propertyDetailsOne.setBusinessDetails(null);
		assertEquals(propertyDetailsOne.getBusinessDetails(), null);
	}
}
