package com.policyadministration.consumerservice.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class ConsumerBusinessTest {
	
	
	ConsumerBusiness consumerBusinessOne =new ConsumerBusiness();
	ConsumerBusiness consumerBusinessTwo =new ConsumerBusiness(null,null);
	
	@Test
	public void testConsumer()
	{
		consumerBusinessOne.setConsumerDetails(null);
		assertEquals(consumerBusinessOne.getConsumerDetails(), null);
	}
	
	@Test
	public void testBusiness()
	{
		consumerBusinessOne.setBusinessDetails(null);
		assertEquals(consumerBusinessOne.getBusinessDetails(), null);
	}
}
