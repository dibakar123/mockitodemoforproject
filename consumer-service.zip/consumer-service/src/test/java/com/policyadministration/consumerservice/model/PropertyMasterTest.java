package com.policyadministration.consumerservice.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class PropertyMasterTest {
PropertyMaster propertyMasterOne = new PropertyMaster();
	
PropertyMaster propertyMasterTwo = new PropertyMaster(1,22,45,5);
	
	
	@Test
	public void testBid()
	{
		propertyMasterOne.setId(1);
		assertEquals(propertyMasterOne.getId(), 1);
		
	}
	@Test
	public void testMin()
	{
		propertyMasterOne.setMinAge(22);
		assertEquals(propertyMasterOne.getMinAge(),22);
		
	}
	@Test
	public void testMax()
	{
		propertyMasterOne.setMaxAge(45);
		assertEquals(propertyMasterOne.getMaxAge(), 45);
		
	}
	@Test
	public void testIndex()
	{
		propertyMasterOne.setIndex(5);;
		assertEquals(propertyMasterOne.getIndex(),5);
		
	}
	

}
