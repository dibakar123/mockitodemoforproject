package com.policyadministration.consumerservice.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.sql.Date;
import java.time.LocalDate;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.policyadministration.consumerservice.exception.BusinessNotFoundException;
import com.policyadministration.consumerservice.exception.PropertyNotFoundException;
import com.policyadministration.consumerservice.exception.TokenInvalidException;
import com.policyadministration.consumerservice.feign.AuthenticationProxy;
import com.policyadministration.consumerservice.model.BusinessDetails;
import com.policyadministration.consumerservice.model.ConsumerBusiness;
import com.policyadministration.consumerservice.model.ConsumerDetails;
import com.policyadministration.consumerservice.model.PropertyDetails;
import com.policyadministration.consumerservice.model.ValidationResponse;
import com.policyadministration.consumerservice.service.ConsumerService;

@SpringBootTest(classes =ConsumerControllerTest.class)
public class ConsumerControllerTest {
	
	@InjectMocks
	private ConsumerController consumerController;
	
	//@Mock
	//private AuthenticationProxy authenticationProxy;
	
	@Mock
	ConsumerService consumerService;
	
	@Test
	 public void testCreateConsumer() throws Exception {
	 
	 BusinessDetails businessDetails1 = new BusinessDetails(1L, "IT", "Corporate",(double)20000, 100L, (double)10000, 1,
			 new ConsumerDetails(1L, "Digu", null,"xyz@gmail.com", "67ER3W", "Corporate", 3, "Agent1", null));
	 ResponseEntity<BusinessDetails> business=new ResponseEntity<BusinessDetails>((businessDetails1),HttpStatus.OK);
	 ConsumerDetails counsumerDetails=new ConsumerDetails(1L, "Digu",Date.valueOf(LocalDate.now()), "xyz@gmail.com", "67ER3W", "Corporate", 3, "Agent1", 
			 new BusinessDetails(1L, "IT", "Corporate", (double)20000, 100L, (double)10000,1,null));
	 ConsumerBusiness consumerBusiness=new ConsumerBusiness(counsumerDetails,businessDetails1);
	 when(consumerService.createConsumerBusiness(consumerBusiness,"Bearer token")).thenReturn(business.getBody());
	 assertEquals(businessDetails1,(consumerController.createConsumerBusiness(consumerBusiness,"Bearer token")).getBody());
}
	
	
	@Test
	public void testCreateBusinessProperty() throws Exception {
		
		PropertyDetails propertyDetailsTwo = new PropertyDetails(
				1L, 345L, "Land", 5, 3, 1, 
				new BusinessDetails(1L, "IT", "Corporate", (double)20000, 100L,(double)10000, 1, 
				new ConsumerDetails(1L, "Digu",Date.valueOf(LocalDate.now()), "xyz@gmail.com", "67ER3W", "Corporate",3, "Agent1", null)));
		ResponseEntity<PropertyDetails>property=new ResponseEntity((propertyDetailsTwo),HttpStatus.OK);
		when(consumerService.createBusinessProperty(propertyDetailsTwo, 1L,"Bearer token")).thenReturn(property.getBody());
		assertEquals(propertyDetailsTwo,(consumerController.createBusinessProperty(propertyDetailsTwo, 1L,"Bearer token")).getBody());
	}
	
	@Test
	public void testUpdateConsumerBusiness() throws Exception {
		BusinessDetails businessDetails1 = new BusinessDetails(
				 1L, "IT", "Corporate",(double)20000, 100L, (double)10000, 1,
				 new ConsumerDetails(1L, "Digu", null, "xyz@gmail.com", "67ER3W", "Corporate", 3, "Agent1", null));
				
		 ConsumerDetails counsumerDetails=new ConsumerDetails(
				 1L, "Digu",Date.valueOf( LocalDate.now()), "xyz@gmail.com", "67ER3W", "Corporate", 3, "Agent1", 
				 new BusinessDetails(1L, "IT", "Corporate", (double)20000, 100L, (double)10000,1,null));
				 
		 ConsumerBusiness consumerBusiness=new ConsumerBusiness(counsumerDetails,businessDetails1);
		 consumerService.updateConsumerBusiness(1L, consumerBusiness, "Bearer token");
		 consumerController.updateConsumerBusiness(consumerBusiness, 1L, "Bearer token");
		//assertEquals(true,consumerController.updateConsumerBusiness(consumerBusiness, 1L, "Bearer token").contains(consumerBusiness));
	}
	
	@Test
	public void testUpdateBusinessProperty() throws Exception {
		PropertyDetails propertyDetailsTwo = new PropertyDetails(
				1L, 345L, "Land", 5,3, 1, 
				new BusinessDetails(1L, "IT", "Corporate", (double)20000, 100L,(double)10000, 1, 
				new ConsumerDetails(1L,"Digu",Date.valueOf(LocalDate.now()), "xyz@gmail.com", "67ER3W", "Corporate",3, "Agent1", null)));
		consumerService.updateBusinessProperty(1L,1L, propertyDetailsTwo, "Bearer token" );
		consumerController.updateBusinessProperty(propertyDetailsTwo, 1L,1L, "Bearer token");
		
	}
	
	@Test
	public void testViewConsumerBusiness() throws Exception {
		BusinessDetails businessDetails1 = new BusinessDetails(
				1L, "IT", "Corporate", (double)20000, 100L, (double)10000, 1,
				new ConsumerDetails(1L, "Digu", null, "xyz@gmail.com", "67ER3W", "Corporate", 3, "Agent1", null));
				
		ConsumerDetails counsumerDetails=new ConsumerDetails(
				1L, "Digu",Date.valueOf(LocalDate.now()), "xyz@gmail.com", "67ER3W", "Corporate", 3, "Agent1", 
				new	 BusinessDetails(1L, "IT", "Corporate", (double)20000, 100L, (double)10000,1,null));
		when(consumerService.viewConsumerBusiness(1L, "Bearer token")).thenReturn(businessDetails1);
		assertEquals(businessDetails1,consumerController.viewConsumerBusiness(1L,"Bearer token" ));
		
	}
	
	
	@Test
	public void testViewBusinessProperty() throws Exception {
		PropertyDetails propertyDetailsTwo = new PropertyDetails(
				1L, 345L, "Land", 5,3, 1, 
				new BusinessDetails(1L, "IT", "Corporate", (double)20000, 100L,(double)10000, 1, 
				new ConsumerDetails(1L,"Digu",Date.valueOf(LocalDate.now()), "xyz@gmail.com", "67ER3W", "Corporate",3, "Agent1", null)));
		when(consumerService.viewPropertyDetails(1L,1L,"Bearer token")).thenReturn(propertyDetailsTwo);
		assertEquals(propertyDetailsTwo,consumerController.viewConsumerProperty(1L,1L,"Bearer token"));
	}
}