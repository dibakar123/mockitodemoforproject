package com.policyadministration.consumerservice.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class BusinessMasterTest 
{
	BusinessMaster businessMasterOne = new BusinessMaster();
	
	BusinessMaster businessMasterTwo = new BusinessMaster(1,3,2,5);
	
	
	@Test
	public void testBid()
	{
		businessMasterOne.setId(1);
		assertEquals(businessMasterOne.getId(), 1);
		
	}
	@Test
	public void testMin()
	{
		businessMasterOne.setMinPercent(3);;
		assertEquals(businessMasterOne.getMinPercent(), 3);
		
	}
	@Test
	public void testMax()
	{
		businessMasterOne.setMaxPercent(2);;
		assertEquals(businessMasterOne.getMaxPercent(), 2);
		
	}
	@Test
	public void testIndex()
	{
		businessMasterOne.setIndex(5);;
		assertEquals(businessMasterOne.getIndex(),5);
		
	}
	

}
