package com.cts.product.exception;

public class ProductNotFoundException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ProductNotFoundException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}

}
