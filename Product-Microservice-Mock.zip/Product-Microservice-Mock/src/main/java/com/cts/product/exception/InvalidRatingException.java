package com.cts.product.exception;

public class InvalidRatingException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidRatingException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}

}
