insert into products (id,price, name, description, image_name, rating) 
values (1,1999.99,'Mobile','4 GB Ram lighweigth Mobile Phone',
'https://tse1.mm.bing.net/th?id=OIP.LyDtTVgSLUJsWRq7TKJdBQHaHa&pid=Api&P=0&w=300&h=300',4.5);
insert into products (id,price, name, description, image_name, rating) 
values (2,2999.99,'Laptop','8 GB Ram, 552 GB SSD Hard Drive',
'https://images.idgesg.net/images/article/2019/10/aceraspire1-100815704-large.jpg',4.5);
insert into products (id,price, name, description, image_name, rating) 
values (3,3999.99,'Key Board','Bluetooth Connectivity wireless Keyboard for Laptops and Computers',
'https://9to5toys.com/wp-content/uploads/sites/5/2018/01/logitech-k360-wireless-keyboard-wireless-keyboard.jpg?quality=82&strip=all',4.5);
insert into products (id,price, name, description, image_name, rating)
values (4,4999.99,'External Hard Disk','2 TB external Hard Disk for Mobile Phones, Laptops and Computers',
'https://images.idgesg.net/images/article/2018/04/drive-cropped-100754535-large.jpg',4.5);
insert into products (id,price, name, description, image_name, rating)
values (5,4999.99,'Tablet','3 GB Ram lightweight Tablet',
'https://globeinform.com/wp-content/uploads/2017/12/Want-Android-5-0-Lollipop-on-the-Cheap-Polaroid-s-L7-Tablet-Costs-Just-99-469417-2-1024x700.jpg',4.5);
insert into products (id,price, name, description, image_name, rating)
values (6,4999.99,'Head Phones','Bluetooth Connectivity wireless Head Phones for Laptops and Computers',
'https://tse3.mm.bing.net/th?id=OIP.bXX8tOtN_zKeBS45JP2ZHwHaJl&pid=Api&P=0&w=300&h=300',4.5);